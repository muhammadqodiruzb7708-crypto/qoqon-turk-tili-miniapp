# QO‘QON TURK TILI — Mini App v1

Bu versiyada:
- Telefon uchun responsive Mini App
- PC/Laptop uchun keng ekran layout
- yengil CSS animatsiyalar
- Telegram WebApp integratsiyasi
- `/start` dan Mini App tugmasi
- UFQ dasturchi krediti: @ufq_svc
- UFQ kanali: https://t.me/ufq_off

## Render Environment

Qo‘shing:
- BOT_TOKEN=...
- ADMIN_SECRET_KEY=...
- WEBAPP_URL=https://YOUR-RENDER-SERVICE.onrender.com/app

Start command:
python Qoqon_Turk_Tili_Bot_MiniApp.py

## Keyingi bosqich
Mini App'ni SQLite bilan ulash:
- haqiqiy foydalanuvchi profili
- haqiqiy testlar
- test natijalarini DB ga yozish
- haqiqiy reyting
- admin panel
- Telegram WebApp initData server-side tekshiruvi
