const tg = window.Telegram?.WebApp;
if (tg) {
  tg.ready();
  tg.expand();
  try { tg.setHeaderColor("#07111f"); tg.setBackgroundColor("#07111f"); } catch(e) {}
}

const user = tg?.initDataUnsafe?.user;
if (user) {
  const full = [user.first_name, user.last_name].filter(Boolean).join(" ");
  document.querySelector("#name").textContent = full || "Foydalanuvchi";
  document.querySelector("#avatar").textContent = (user.first_name || "U")[0].toUpperCase();
}

const sections = [...document.querySelectorAll(".section")];
const navs = [...document.querySelectorAll(".nav")];
const title = document.querySelector("#pageTitle");

const titles = {
  home: "Bosh sahifa",
  courses: "Kurslar",
  grammar: "Grammatika",
  vocab: "Lug‘atlar",
  tests: "Testlar",
  rating: "Reyting",
  teacher: "O‘qituvchi"
};

function openSection(id) {
  sections.forEach(s => s.classList.toggle("active", s.id === id));
  navs.forEach(n => n.classList.toggle("active", n.dataset.section === id));
  title.textContent = titles[id] || "Qo‘qon Turk Tili";
  window.scrollTo({top:0, behavior:"smooth"});
}

document.addEventListener("click", e => {
  const target = e.target.closest("[data-section]");
  if (target) openSection(target.dataset.section);
});

document.querySelector("#closeBtn")?.addEventListener("click", () => {
  if (tg) tg.close();
});

document.querySelector(".test-start")?.addEventListener("click", () => {
  if (tg?.showAlert) tg.showAlert("Testlar keyingi bosqichda botdagi haqiqiy SQLite test tizimiga ulanadi.");
  else alert("Testlar keyingi bosqichda ulanadi.");
});
