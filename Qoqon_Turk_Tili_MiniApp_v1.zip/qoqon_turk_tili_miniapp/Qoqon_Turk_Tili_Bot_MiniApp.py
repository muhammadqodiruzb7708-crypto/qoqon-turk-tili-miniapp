import asyncio
import logging
import os
from pathlib import Path
import sqlite3
import threading
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    Message,
    ReplyKeyboardMarkup,
    WebAppInfo,
)

# ============================================================
# QO'QON TURK TILI BOT — RENDER PRODUCTION VERSION
# ============================================================
# Required environment variables on Render:
#   BOT_TOKEN
#   ADMIN_SECRET_KEY
#
# Optional:
#   DB_NAME (default: qoqon_turk_bot.db)
#   UFQ_DEV_PROFILE
#   UFQ_CHANNEL_URL
#   COURSE_CHANNEL_URL
#
# IMPORTANT:
# - Never put BOT_TOKEN or ADMIN_SECRET_KEY directly in this file.
# - For persistent SQLite storage on Render, mount a persistent disk
#   and set DB_NAME to a path on that disk, e.g. /var/data/qoqon_turk_bot.db.
# ============================================================

logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO").upper(),
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
logger = logging.getLogger("qoqon_turk_tili_bot")

BOT_TOKEN = os.getenv("BOT_TOKEN")
ADMIN_SECRET_KEY = os.getenv("ADMIN_SECRET_KEY")

if not BOT_TOKEN:
    raise RuntimeError("BOT_TOKEN environment variable is missing.")

if not ADMIN_SECRET_KEY:
    raise RuntimeError("ADMIN_SECRET_KEY environment variable is missing.")

DB_NAME = os.getenv("DB_NAME", "qoqon_turk_bot.db")

UFQ_DEV_PROFILE = os.getenv("UFQ_DEV_PROFILE", "https://t.me/ufq_svc")
UFQ_CHANNEL_URL = os.getenv("UFQ_CHANNEL_URL", "https://t.me/ufq_off")
COURSE_CHANNEL_URL = os.getenv(
    "COURSE_CHANNEL_URL", "https://t.me/qoqon_turktili"
)

UFQ_BRAND_TEXT = (
    "⚡ **UFQ | Dasturlash • Dizayn • IT**\n"
    "🚀 *G‘oyadan tayyor loyihagacha*\n"
    "💻 *Kod. G‘oya. Natija.*\n\n"
    "Sizga ham o‘quv markazingiz yoki biznesingiz uchun sifatli bot, "
    "sayt yoki IT yechim kerakmi?\n\n"
    "👤 **Dasturchi:** @ufq_svc\n"
    "📢 **Kanalimiz:** [t.me/ufq_off](https://t.me/ufq_off)"
)

UFQ_FOOTER = (
    "\n\n────────────────\n"
    "⚡ _Dasturchi: [@ufq_svc](https://t.me/ufq_svc) • "
    "Kanal: [@ufq_off](https://t.me/ufq_off)_"
)

# ============================================================
# RENDER HEALTH SERVER
# ============================================================

class RenderHealthServer(BaseHTTPRequestHandler):
    def do_GET(self):
        # Telegram Mini App
        if self.path in ("/", "/app", "/app/"):
            app_file = Path(__file__).resolve().parent / "webapp" / "index.html"
            if app_file.exists():
                data = app_file.read_bytes()
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Cache-Control", "no-cache")
                self.end_headers()
                self.wfile.write(data)
                return

        if self.path.startswith("/app/"):
            rel = self.path[len("/app/"):].split("?", 1)[0]
            if rel and ".." not in rel:
                app_file = Path(__file__).resolve().parent / "webapp" / rel
                if app_file.is_file():
                    data = app_file.read_bytes()
                    content_types = {
                        ".css": "text/css; charset=utf-8",
                        ".js": "application/javascript; charset=utf-8",
                        ".svg": "image/svg+xml",
                        ".png": "image/png",
                        ".jpg": "image/jpeg",
                        ".jpeg": "image/jpeg",
                        ".webp": "image/webp",
                    }
                    self.send_response(200)
                    self.send_header(
                        "Content-Type",
                        content_types.get(app_file.suffix.lower(), "application/octet-stream")
                    )
                    self.end_headers()
                    self.wfile.write(data)
                    return

        self.send_response(200)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.end_headers()
        self.wfile.write(b"Qoqon Turk Tili boti faol ishlamoqda!")

    def do_HEAD(self):
        self.send_response(200)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.end_headers()

    def log_message(self, format, *args):
        return


def run_http_server():
    port = int(os.getenv("PORT", "8080"))
    server = ThreadingHTTPServer(("0.0.0.0", port), RenderHealthServer)
    logger.info("Render health server listening on port %s", port)
    try:
        server.serve_forever()
    finally:
        server.server_close()


# ============================================================
# DATABASE
# ============================================================

def db_connect():
    conn = sqlite3.connect(DB_NAME, timeout=30)
    conn.execute("PRAGMA busy_timeout = 30000")
    return conn


def init_db():
    with db_connect() as conn:
        cursor = conn.cursor()

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                full_name TEXT NOT NULL,
                username TEXT DEFAULT '',
                score INTEGER DEFAULT 0,
                registered_at TEXT NOT NULL
            )
        """)

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS admins (
                user_id INTEGER PRIMARY KEY,
                full_name TEXT NOT NULL,
                added_at TEXT NOT NULL
            )
        """)

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS tests (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                is_active INTEGER DEFAULT 1
            )
        """)

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS questions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                test_id INTEGER NOT NULL,
                question_text TEXT NOT NULL,
                opt_a TEXT NOT NULL,
                opt_b TEXT NOT NULL,
                opt_c TEXT NOT NULL,
                opt_d TEXT NOT NULL,
                correct TEXT NOT NULL,
                points INTEGER DEFAULT 5
            )
        """)

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS content (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            )
        """)

        default_contents = [
            (
                "teacher",
                (
                    "🇹🇷 **QO‘QON TURK TILI**\n\n"
                    "👨‍🏫 **Öğretmen Abduvohid Karimov**\n"
                    "• Oliy ma'lumotli pedagog 🎓\n"
                    "• Magistr darajasiga ega mutaxassis\n"
                    "• Ko'p yillik tajribali turk tili ustozi\n"
                    "• Turkiyadagi nufuzli OTMlarga tayyorlovchi "
                    "yetakchi pedagog"
                ),
            ),
            (
                "lessons",
                (
                    "📕 **Online Turk tili darslari (Qo‘qon Turk Tili):**\n\n"
                    "• A1 - Boshlang'ich daraja\n"
                    "• A2 - Mustahkamlash bosqichi\n"
                    "• B1/B2 - Erkin muloqot va C1 akademik tayyorgarlik\n\n"
                    "Darslar haftada 3 kun jonli muloqot va interaktiv "
                    "mashg'ulotlar asosida olib boriladi."
                ),
            ),
            (
                "turkey",
                (
                    "🇹🇷 **Turkiyada ta'lim olish imkoniyatlari:**\n\n"
                    "Bakalavr, Magistratura va Doktoranturada o'qishni "
                    "istaysizmi?\n\n"
                    "• Türkiye Bursları grant dasturlari\n"
                    "• Universitet tanlash va hujjat topshirish\n"
                    "• TÖMER til sertifikati tayyorlovi bo'yicha to'liq ko'mak."
                ),
            ),
            (
                "grammar",
                (
                    "📚 **Grammatika bo'limi:**\n\n"
                    "Turk tili grammatik qoidalari, fe'l zamonlari va "
                    "qo'shimchalar bo'yicha maxsus darsliklar."
                ),
            ),
            (
                "vocab",
                (
                    "📖 **Lug'atlar bo'limi:**\n\n"
                    "Mavzulashgan so'zliklar, eng ko'p ishlatiladigan "
                    "1000 ta so'z va kundalik iboralar."
                ),
            ),
            (
                "contact",
                (
                    "📞 **QO‘QON TURK TILI bilan bog'lanish:**\n\n"
                    "Kurslarga yozilish yoki savollar uchun:\n"
                    "📍 Manzil: Qo'qon shahri\n"
                    "📢 Rasmiy kanal: @qoqon_turktili\n"
                    "📞 Telefon: +998 (90) 123-45-67"
                ),
            ),
        ]

        for key, value in default_contents:
            cursor.execute(
                "INSERT OR IGNORE INTO content (key, value) VALUES (?, ?)",
                (key, value),
            )

        conn.commit()


def get_content(key: str) -> str:
    with db_connect() as conn:
        row = conn.execute(
            "SELECT value FROM content WHERE key = ?", (key,)
        ).fetchone()

    return row[0] if row else "Ma'lumot tez orada joylanadi."


def set_content(key: str, value: str):
    with db_connect() as conn:
        conn.execute(
            """
            INSERT INTO content (key, value)
            VALUES (?, ?)
            ON CONFLICT(key) DO UPDATE SET value = excluded.value
            """,
            (key, value),
        )
        conn.commit()


def is_admin(user_id: int) -> bool:
    with db_connect() as conn:
        row = conn.execute(
            "SELECT 1 FROM admins WHERE user_id = ?", (user_id,)
        ).fetchone()
    return row is not None


def register_user(message: Message):
    user = message.from_user
    full_name = user.full_name or "Foydalanuvchi"
    username = user.username or ""
    now = datetime.now(timezone.utc).isoformat()

    with db_connect() as conn:
        conn.execute(
            """
            INSERT INTO users
                (user_id, full_name, username, registered_at)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET
                full_name = excluded.full_name,
                username = excluded.username
            """,
            (user.id, full_name, username, now),
        )
        conn.commit()


# ============================================================
# FSM STATES
# ============================================================

class AuthStates(StatesGroup):
    waiting_code = State()


class AdminTestStates(StatesGroup):
    test_title = State()


class AdminQuestionStates(StatesGroup):
    select_test = State()
    q_text = State()


class AdminContentStates(StatesGroup):
    new_text = State()


class AdminBroadcastStates(StatesGroup):
    message = State()


# ============================================================
# KEYBOARDS
# ============================================================

user_menu = ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton(text="📕 Online darslar"),
            KeyboardButton(text="📚 Grammatika"),
        ],
        [
            KeyboardButton(text="📖 Lug'atlar"),
            KeyboardButton(text="📝 Testlar"),
        ],
        [
            KeyboardButton(text="🏆 Reyting"),
            KeyboardButton(text="🇹🇷 Turkiyada ta'lim"),
        ],
        [
            KeyboardButton(text="👨‍🏫 O'qituvchi haqida"),
            KeyboardButton(text="📞 Kursga yozilish"),
        ],
        [
            KeyboardButton(text="📢 Rasmiy kanal"),
            KeyboardButton(text="⚡ UFQ | Dasturchi"),
        ],
    ],
    resize_keyboard=True,
)

admin_menu_kb = ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton(text="➕ Yangi test yaratish"),
            KeyboardButton(text="➕ Savol qo'shish"),
        ],
        [
            KeyboardButton(text="✏️ Matnlarni tahrirlash"),
            KeyboardButton(text="📢 E'lon yuborish"),
        ],
        [
            KeyboardButton(text="📊 Reytingni boshqarish"),
            KeyboardButton(text="🔙 Foydalanuvchi menyusi"),
        ],
    ],
    resize_keyboard=True,
)


# ============================================================
# BOT
# ============================================================

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(storage=MemoryStorage())


# ============================================================
# START
# ============================================================

@dp.message(CommandStart())
async def start_handler(message: Message):
    register_user(message)

    fname = message.from_user.full_name or "Foydalanuvchi"

    text = (
        f"Assalomu alaykum, **{fname}**!\n\n"
        "🇹🇷 **QO‘QON TURK TILI** platformasiga xush kelibsiz!\n\n"
        "Bakalavr, Magistratura va Doktoranturada o'qishni istaysizmi?\n"
        "Biz bilan turk tilini online tarzda qulay va samarali o'rganing!\n\n"
        "Bizda:\n"
        "📕 Online darslar\n"
        "📚 Grammatika\n"
        "📖 Lug'atlar\n"
        "📝 Testlar va sovg'ali reyting"
        f"{UFQ_FOOTER}"
    )

    inline_rows = []

    if WEBAPP_URL:
        inline_rows.append([
            InlineKeyboardButton(
                text="🚀 QO‘QON TURK TILI ilovasini ochish",
                web_app=WebAppInfo(url=WEBAPP_URL),
            )
        ])

    if COURSE_CHANNEL_URL:
        inline_rows.append([
            InlineKeyboardButton(
                text="📢 Qo‘qon Turk Tili kanali",
                url=COURSE_CHANNEL_URL,
            )
        ])

    inline_ch = InlineKeyboardMarkup(inline_keyboard=inline_rows)

    await message.answer(
        text,
        reply_markup=user_menu,
        parse_mode="Markdown",
    )

    if inline_ch.inline_keyboard:
        await message.answer(
            "Ilovani oching yoki markazimiz kanaliga o'ting:",
            reply_markup=inline_ch,
        )


# ============================================================
# AUTH
# ============================================================

@dp.message(Command("auth"))
async def auth_command(message: Message, state: FSMContext):
    if is_admin(message.from_user.id):
        await message.answer(
            "Siz allaqachon administratorsiz! Boshqaruv uchun: /admin"
        )
        return

    await message.answer(
        "🔐 Administratorlik huquqini olish uchun maxfiy kodni kiriting:"
    )
    await state.set_state(AuthStates.waiting_code)


@dp.message(AuthStates.waiting_code)
async def process_auth_code(message: Message, state: FSMContext):
    code = (message.text or "").strip()

    if code == ADMIN_SECRET_KEY:
        with db_connect() as conn:
            conn.execute(
                """
                INSERT OR REPLACE INTO admins
                    (user_id, full_name, added_at)
                VALUES (?, ?, ?)
                """,
                (
                    message.from_user.id,
                    message.from_user.full_name or "Admin",
                    datetime.now(timezone.utc).isoformat(),
                ),
            )
            conn.commit()

        await message.answer(
            "✅ **Tabriklaymiz!** Sizga muvaffaqiyatli administrator "
            "huquqi berildi.\n"
            "Boshqaruv paneliga kirish uchun: /admin",
            parse_mode="Markdown",
        )
    else:
        await message.answer(
            "❌ Noto'g'ri maxfiy kod kiritildi! Ruxsat berilmadi."
        )

    await state.clear()


# ============================================================
# USER SECTIONS
# ============================================================

@dp.message(F.text == "👨‍🏫 O'qituvchi haqida")
async def show_teacher(message: Message):
    await message.answer(
        get_content("teacher") + UFQ_FOOTER,
        parse_mode="Markdown",
    )


@dp.message(F.text == "📕 Online darslar")
async def show_lessons(message: Message):
    await message.answer(
        get_content("lessons") + UFQ_FOOTER,
        parse_mode="Markdown",
    )


@dp.message(F.text == "🇹🇷 Turkiyada ta'lim")
async def show_turkey(message: Message):
    await message.answer(
        get_content("turkey") + UFQ_FOOTER,
        parse_mode="Markdown",
    )


@dp.message(F.text == "📚 Grammatika")
async def show_grammar(message: Message):
    await message.answer(
        get_content("grammar") + UFQ_FOOTER,
        parse_mode="Markdown",
    )


@dp.message(F.text == "📖 Lug'atlar")
async def show_vocab(message: Message):
    await message.answer(
        get_content("vocab") + UFQ_FOOTER,
        parse_mode="Markdown",
    )


@dp.message(F.text == "📞 Kursga yozilish")
async def show_contact(message: Message):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="📢 Rasmiy kanalga o'tish",
                    url=COURSE_CHANNEL_URL,
                )
            ]
        ]
    )

    await message.answer(
        get_content("contact") + UFQ_FOOTER,
        reply_markup=kb,
        parse_mode="Markdown",
    )


@dp.message(F.text == "📢 Rasmiy kanal")
async def show_channel(message: Message):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="👉 Kanalga a'zo bo'lish",
                    url=COURSE_CHANNEL_URL,
                )
            ]
        ]
    )

    await message.answer(
        "QO‘QON TURK TILI rasmiy kanaliga obuna bo'ling:",
        reply_markup=kb,
    )


@dp.message(F.text == "⚡ UFQ | Dasturchi")
async def show_ufq_promo(message: Message):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="💬 Dasturchi (@ufq_svc)",
                    url=UFQ_DEV_PROFILE,
                )
            ],
            [
                InlineKeyboardButton(
                    text="📢 UFQ rasmiy kanali (@ufq_off)",
                    url=UFQ_CHANNEL_URL,
                )
            ],
        ]
    )

    await message.answer(
        UFQ_BRAND_TEXT,
        reply_markup=kb,
        parse_mode="Markdown",
    )


# ============================================================
# LEADERBOARD
# ============================================================

@dp.message(F.text == "🏆 Reyting")
async def show_leaderboard(message: Message):
    register_user(message)

    with db_connect() as conn:
        top_users = conn.execute(
            """
            SELECT full_name, score
            FROM users
            ORDER BY score DESC, full_name ASC
            LIMIT 10
            """
        ).fetchall()

        user_row = conn.execute(
            "SELECT score FROM users WHERE user_id = ?",
            (message.from_user.id,),
        ).fetchone()

    score = user_row[0] if user_row else 0

    text = (
        "🏆 **Qo‘qon Turk Tili o'quvchilari reytingi (Top 10):**\n\n"
    )

    medals = (
        "🥇", "🥈", "🥉", "4.", "5.",
        "6.", "7.", "8.", "9.", "10."
    )

    if not top_users:
        text += "Hozircha hech kim test ishlamadi. Birinchi bo'ling!\n"
    else:
        for idx, (u_name, u_score) in enumerate(top_users):
            medal_label = (
                medals[idx] if idx < len(medals) else f"{idx + 1}."
            )
            text += f"{medal_label} **{u_name}** — {u_score} ball\n"

    text += (
        f"\n────────────────\n"
        f"⭐️ **Sizning balingiz:** {score} ball\n"
        "Test ishlab o'z o'rningizni oshiring!"
    )

    text += UFQ_FOOTER

    await message.answer(text, parse_mode="Markdown")


# ============================================================
# TEST LIST
# ============================================================

@dp.message(F.text == "📝 Testlar")
async def list_available_tests(message: Message):
    register_user(message)

    with db_connect() as conn:
        tests = conn.execute(
            """
            SELECT id, title
            FROM tests
            WHERE is_active = 1
            ORDER BY id DESC
            """
        ).fetchall()

    if not tests:
        await message.answer(
            "Hozirda faol testlar mavjud emas. "
            "Tez orada yangi testlar joylanadi!"
        )
        return

    buttons = [
        [
            InlineKeyboardButton(
                text=f"📝 {title}",
                callback_data=f"start_test:{test_id}",
            )
        ]
        for test_id, title in tests
    ]

    await message.answer(
        "Ishlamoqchi bo'lgan testingizni tanlang:",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons),
    )


# ============================================================
# START QUIZ
# ============================================================

@dp.callback_query(F.data.startswith("start_test:"))
async def start_quiz(callback: CallbackQuery, state: FSMContext):
    try:
        test_id = int(callback.data.split(":", 1)[1])
    except (ValueError, IndexError):
        await callback.answer("Test ID noto'g'ri.", show_alert=True)
        return

    with db_connect() as conn:
        test = conn.execute(
            "SELECT id, title FROM tests WHERE id = ? AND is_active = 1",
            (test_id,),
        ).fetchone()

        questions = conn.execute(
            """
            SELECT
                id, question_text, opt_a, opt_b, opt_c, opt_d,
                correct, points
            FROM questions
            WHERE test_id = ?
            ORDER BY id ASC
            """,
            (test_id,),
        ).fetchall()

    if not test:
        await callback.answer(
            "Bu test mavjud emas yoki faol emas.",
            show_alert=True,
        )
        return

    if not questions:
        await callback.message.answer(
            "Bu testda hozircha savollar yo'q."
        )
        await callback.answer()
        return

    await state.update_data(
        test_id=test_id,
        q_index=0,
        questions=questions,
        score=0,
    )

    await callback.answer()
    await send_next_question(callback.message, state)


async def send_next_question(message: Message, state: FSMContext):
    data = await state.get_data()

    if not data or "questions" not in data:
        return

    q_index = data["q_index"]
    questions = data["questions"]

    if q_index >= len(questions):
        final_score = int(data.get("score", 0))
        uid = message.chat.id

        with db_connect() as conn:
            conn.execute(
                "UPDATE users SET score = score + ? WHERE user_id = ?",
                (final_score, uid),
            )
            conn.commit()

        await message.answer(
            f"🎉 **Test yakunlandi!**\n\n"
            f"Siz to'plagan ball: **+{final_score} ball**\n"
            "Reytingingiz muvaffaqiyatli yangilandi!"
            f"{UFQ_FOOTER}",
            parse_mode="Markdown",
        )

        await state.clear()
        return

    q = questions[q_index]

    (
        q_id,
        q_text_val,
        opt_a_val,
        opt_b_val,
        opt_c_val,
        opt_d_val,
        _correct_val,
        _points_val,
    ) = q

    q_text = (
        f"**{q_index + 1}-savol:** {q_text_val}\n\n"
        f"A) {opt_a_val}\n"
        f"B) {opt_b_val}\n"
        f"C) {opt_c_val}\n"
        f"D) {opt_d_val}"
    )

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="A",
                    callback_data=f"ans:A:{q_id}",
                ),
                InlineKeyboardButton(
                    text="B",
                    callback_data=f"ans:B:{q_id}",
                ),
                InlineKeyboardButton(
                    text="C",
                    callback_data=f"ans:C:{q_id}",
                ),
                InlineKeyboardButton(
                    text="D",
                    callback_data=f"ans:D:{q_id}",
                ),
            ]
        ]
    )

    await message.answer(
        q_text,
        reply_markup=kb,
        parse_mode="Markdown",
    )


# ============================================================
# ANSWER HANDLER
# ============================================================

@dp.callback_query(F.data.startswith("ans:"))
async def handle_answer(callback: CallbackQuery, state: FSMContext):
    parts = callback.data.split(":")

    if len(parts) != 3:
        await callback.answer(
            "Javob ma'lumotlari noto'g'ri.",
            show_alert=True,
        )
        return

    # FIXED:
    # Old code used choice = parts, which created a list.
    # Correct answer is the second callback component.
    choice = parts[1].strip().upper()

    try:
        question_id = int(parts[2])
    except ValueError:
        await callback.answer("Savol ID noto'g'ri.", show_alert=True)
        return

    if choice not in {"A", "B", "C", "D"}:
        await callback.answer("Javob varianti noto'g'ri.", show_alert=True)
        return

    data = await state.get_data()

    if not data or "questions" not in data:
        await callback.answer("Test yakunlangan.", show_alert=True)
        return

    questions = data["questions"]
    q_index = data["q_index"]

    if q_index >= len(questions):
        await callback.answer("Test yakunlangan.", show_alert=True)
        return

    current_q = questions[q_index]
    current_q_id = current_q[0]

    # Prevent a callback from an older/different question from
    # being accepted for the current question.
    if question_id != current_q_id:
        await callback.answer(
            "Bu savol endi faol emas.",
            show_alert=True,
        )
        return

    correct_val = str(current_q[6]).strip().upper()
    points_val = int(current_q[7])

    if choice == correct_val:
        new_score = int(data.get("score", 0)) + points_val

        await state.update_data(score=new_score)
        await callback.answer("✅ To'g'ri!")
    else:
        await callback.answer(
            f"❌ Noto'g'ri! To'g'ri javob: {correct_val}",
            show_alert=True,
        )

    await state.update_data(q_index=q_index + 1)
    await send_next_question(callback.message, state)


# ============================================================
# ADMIN PANEL
# ============================================================

@dp.message(Command("admin"))
async def admin_panel(message: Message):
    if not is_admin(message.from_user.id):
        await message.answer(
            "Sizda administratorlik huquqi yo'q. "
            "Kod kiritish uchun: /auth"
        )
        return

    await message.answer(
        "🛠 **Qo‘qon Turk Tili — Admin boshqaruv paneli:**",
        reply_markup=admin_menu_kb,
        parse_mode="Markdown",
    )


@dp.message(F.text == "🔙 Foydalanuvchi menyusi")
async def back_to_user_menu(message: Message, state: FSMContext):
    await state.clear()
    await message.answer(
        "Bosh menyuga qaytildi.",
        reply_markup=user_menu,
    )


# ============================================================
# ADMIN — CREATE TEST
# ============================================================

@dp.message(F.text == "➕ Yangi test yaratish")
async def admin_add_test(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return

    await message.answer(
        "Yangi test mavzusini kiriting "
        "(Masalan: *A1 Daraja - Fe'llar*):",
        parse_mode="Markdown",
    )

    await state.set_state(AdminTestStates.test_title)


@dp.message(AdminTestStates.test_title)
async def process_new_test_title(message: Message, state: FSMContext):
    title = (message.text or "").strip()

    if not title:
        await message.answer("Test nomi bo'sh bo'lishi mumkin emas.")
        return

    with db_connect() as conn:
        conn.execute(
            "INSERT INTO tests (title) VALUES (?)",
            (title,),
        )
        conn.commit()

    await message.answer(
        f"✅ Yangi test qo'shildi: **{title}**\n"
        "Endi unga savollar qo'shishingiz mumkin.",
        parse_mode="Markdown",
    )

    await state.clear()


# ============================================================
# ADMIN — ADD QUESTION
# ============================================================

@dp.message(F.text == "➕ Savol qo'shish")
async def admin_select_test_for_q(
    message: Message,
    state: FSMContext,
):
    if not is_admin(message.from_user.id):
        return

    with db_connect() as conn:
        tests = conn.execute(
            "SELECT id, title FROM tests ORDER BY id DESC"
        ).fetchall()

    if not tests:
        await message.answer("Avval kamida bitta test yarating!")
        return

    text = (
        "Qaysi testga savol qo'shmoqchisiz? "
        "Test ID raqamini yuboring:\n\n"
    )

    for t_id, t_title in tests:
        text += f"ID: `{t_id}` — **{t_title}**\n"

    await message.answer(text, parse_mode="Markdown")
    await state.set_state(AdminQuestionStates.select_test)


@dp.message(AdminQuestionStates.select_test)
async def set_q_test(message: Message, state: FSMContext):
    try:
        t_id = int((message.text or "").strip())
    except ValueError:
        await message.answer("Iltimos, faqat raqam kiriting.")
        return

    with db_connect() as conn:
        test = conn.execute(
            "SELECT id, title FROM tests WHERE id = ?",
            (t_id,),
        ).fetchone()

    if not test:
        await message.answer("Bunday test ID mavjud emas.")
        return

    await state.update_data(test_id=t_id)

    await message.answer(
        "Savol va variantlarni quyidagi formatda bitta xabarda yuboring:\n\n"
        "Savol matni\n"
        "A) 1-variant\n"
        "B) 2-variant\n"
        "C) 3-variant\n"
        "D) 4-variant\n"
        "Javob: A\n"
        "Ball: 5"
    )

    await state.set_state(AdminQuestionStates.q_text)


@dp.message(AdminQuestionStates.q_text)
async def process_full_question(message: Message, state: FSMContext):
    raw_text = message.text or ""
    lines = [line.strip() for line in raw_text.splitlines() if line.strip()]

    if len(lines) < 7:
        await message.answer(
            "Format xato!\n\n"
            "Quyidagicha yuboring:\n"
            "Savol\n"
            "A) variant\n"
            "B) variant\n"
            "C) variant\n"
            "D) variant\n"
            "Javob: A\n"
            "Ball: 5"
        )
        return

    data = await state.get_data()
    t_id = data.get("test_id")

    if not t_id:
        await message.answer(
            "Test tanlanmagan. Jarayonni qaytadan boshlang."
        )
        await state.clear()
        return

    with db_connect() as conn:
        test = conn.execute(
            "SELECT id FROM tests WHERE id = ?",
            (t_id,),
        ).fetchone()

    if not test:
        await message.answer("Tanlangan test mavjud emas.")
        await state.clear()
        return

    # First five lines must be question + A/B/C/D.
    q_text = lines[0]

    expected_prefixes = ["A)", "B)", "C)", "D)"]
    option_values = []

    for index, prefix in enumerate(expected_prefixes, start=1):
        line = lines[index]
        if not line.upper().startswith(prefix):
            await message.answer(
                f"Format xato: {prefix} varianti topilmadi."
            )
            return

        value = line[len(prefix):].strip()

        if not value:
            await message.answer(
                f"{prefix} varianti bo'sh bo'lishi mumkin emas."
            )
            return

        option_values.append(value)

    correct = None
    points = 5

    for line in lines[5:]:
        lower_line = line.lower()

        if lower_line.startswith("javob:"):
            correct = line.split(":", 1)[1].strip().upper()

        elif lower_line.startswith("ball:"):
            try:
                points = int(line.split(":", 1)[1].strip())
            except ValueError:
                await message.answer(
                    "Ball son bo'lishi kerak. Masalan: Ball: 5"
                )
                return

    if correct not in {"A", "B", "C", "D"}:
        await message.answer(
            "To'g'ri javob A, B, C yoki D bo'lishi kerak."
        )
        return

    if points <= 0 or points > 1000:
        await message.answer(
            "Ball 1 dan 1000 gacha bo'lishi kerak."
        )
        return

    with db_connect() as conn:
        conn.execute(
            """
            INSERT INTO questions (
                test_id,
                question_text,
                opt_a,
                opt_b,
                opt_c,
                opt_d,
                correct,
                points
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                t_id,
                q_text,
                option_values[0],
                option_values[1],
                option_values[2],
                option_values[3],
                correct,
                points,
            ),
        )
        conn.commit()

    await message.answer("✅ Savol muvaffaqiyatli saqlandi!")
    await state.clear()


# ============================================================
# ADMIN — EDIT CONTENT
# ============================================================

@dp.message(F.text == "✏️ Matnlarni tahrirlash")
async def edit_content_select(message: Message):
    if not is_admin(message.from_user.id):
        return

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="👨‍🏫 O'qituvchi ma'lumoti",
                    callback_data="edt:teacher",
                )
            ],
            [
                InlineKeyboardButton(
                    text="📕 Kurslar ma'lumoti",
                    callback_data="edt:lessons",
                )
            ],
            [
                InlineKeyboardButton(
                    text="🇹🇷 Turkiyada ta'lim",
                    callback_data="edt:turkey",
                )
            ],
            [
                InlineKeyboardButton(
                    text="📚 Grammatika",
                    callback_data="edt:grammar",
                )
            ],
            [
                InlineKeyboardButton(
                    text="📖 Lug'atlar",
                    callback_data="edt:vocab",
                )
            ],
            [
                InlineKeyboardButton(
                    text="📞 Bog'lanish ma'lumoti",
                    callback_data="edt:contact",
                )
            ],
        ]
    )

    await message.answer(
        "Qaysi bo'lim matnini o'zgartirmoqchisiz?",
        reply_markup=kb,
    )


@dp.callback_query(F.data.startswith("edt:"))
async def edit_content_callback(
    callback: CallbackQuery,
    state: FSMContext,
):
    if not is_admin(callback.from_user.id):
        await callback.answer(
            "Sizda admin huquqi yo'q.",
            show_alert=True,
        )
        return

    _, key = callback.data.split(":", 1)

    allowed_keys = {
        "teacher",
        "lessons",
        "turkey",
        "grammar",
        "vocab",
        "contact",
    }

    if key not in allowed_keys:
        await callback.answer("Bo'lim noto'g'ri.", show_alert=True)
        return

    await state.update_data(key=key)

    curr = get_content(key)

    await callback.message.answer(
        f"Hozirgi matn:\n\n{curr}\n\n"
        "Ushbu bo'lim uchun **yangi matnni** yuboring:",
        parse_mode="Markdown",
    )

    await callback.answer()
    await state.set_state(AdminContentStates.new_text)


@dp.message(AdminContentStates.new_text)
async def save_new_content(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        await state.clear()
        return

    data = await state.get_data()
    key = data.get("key")
    new_text = message.text or ""

    allowed_keys = {
        "teacher",
        "lessons",
        "turkey",
        "grammar",
        "vocab",
        "contact",
    }

    if key not in allowed_keys:
        await message.answer("Bo'lim noto'g'ri.")
        await state.clear()
        return

    if not new_text.strip():
        await message.answer("Matn bo'sh bo'lishi mumkin emas.")
        return

    set_content(key, new_text)

    await message.answer("✅ Matn muvaffaqiyatli yangilandi!")
    await state.clear()


# ============================================================
# ADMIN — BROADCAST
# ============================================================

@dp.message(F.text == "📢 E'lon yuborish")
async def broadcast_prompt(
    message: Message,
    state: FSMContext,
):
    if not is_admin(message.from_user.id):
        return

    await message.answer(
        "Barcha foydalanuvchilarga yuboriladigan xabarni yozing:"
    )
    await state.set_state(AdminBroadcastStates.message)


@dp.message(AdminBroadcastStates.message)
async def process_broadcast(
    message: Message,
    state: FSMContext,
):
    if not is_admin(message.from_user.id):
        await state.clear()
        return

    text = message.text or ""

    if not text.strip():
        await message.answer("Xabar bo'sh bo'lishi mumkin emas.")
        return

    with db_connect() as conn:
        users = conn.execute(
            "SELECT user_id FROM users"
        ).fetchall()

    count = 0

    for (target_user_id,) in users:
        try:
            await bot.send_message(
                target_user_id,
                text + UFQ_FOOTER,
                parse_mode="Markdown",
            )
            count += 1

            # Telegram flood-limitlarga yaqinlashmaslik uchun.
            await asyncio.sleep(0.06)

        except Exception as exc:
            logger.warning(
                "Broadcast failed for user %s: %s",
                target_user_id,
                exc,
            )

    await message.answer(
        f"✅ Xabar {count} ta foydalanuvchiga muvaffaqiyatli yuborildi."
    )

    await state.clear()


# ============================================================
# ADMIN — SCORE MANAGEMENT
# ============================================================

@dp.message(F.text == "📊 Reytingni boshqarish")
async def manage_scores(message: Message):
    if not is_admin(message.from_user.id):
        return

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="🔄 Oylik reytingni nolga tushirish",
                    callback_data="reset_scores",
                )
            ]
        ]
    )

    await message.answer(
        "Reytingni yangilash sozlamalari:",
        reply_markup=kb,
    )


@dp.callback_query(F.data == "reset_scores")
async def reset_scores_cb(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer(
            "Sizda admin huquqi yo'q.",
            show_alert=True,
        )
        return

    with db_connect() as conn:
        conn.execute("UPDATE users SET score = 0")
        conn.commit()

    await callback.message.answer(
        "✅ Barcha o'quvchilar ballari nolga tenglashtirildi."
    )

    await callback.answer()


# ============================================================
# GLOBAL ERROR HANDLER
# ============================================================

@dp.error()
async def global_error_handler(event):
    logger.exception("Unhandled bot error: %s", event.exception)

    try:
        if event.update and event.update.message:
            await event.update.message.answer(
                "⚠️ Texnik xatolik yuz berdi. Iltimos, birozdan "
                "keyin qayta urinib ko'ring."
            )
    except Exception:
        pass


# ============================================================
# MAIN
# ============================================================

async def main():
    init_db()

    # Render requires the web service to bind to PORT.
    health_thread = threading.Thread(
        target=run_http_server,
        daemon=True,
        name="render-health-server",
    )
    health_thread.start()

    logger.info("Qoqon Turk Tili bot starting...")
    logger.info("Database: %s", DB_NAME)

    # Prevent accidental stale webhook from interfering with polling.
    await bot.delete_webhook(drop_pending_updates=True)

    try:
        await dp.start_polling(
            bot,
            allowed_updates=dp.resolve_used_update_types(),
        )
    finally:
        await bot.session.close()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        logger.info("Bot stopped.")
